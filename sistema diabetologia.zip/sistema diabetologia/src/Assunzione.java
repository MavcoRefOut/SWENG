import java.sql.Time;
import java.util.Date;

/**
 * Classe che descrive l'assunzione di un farmaco da parte di un Paziente
 */
public class Assunzione {

    private Date dataAssunzione;
    private Time orario;
    private int quantità;
    private String unitàMisura;
    private Farmaco farmaco;

    /**
     * Costruttore della classe, parametri autodescrittivi
     * @param dataAssunzione
     * @param orario
     * @param quantità
     * @param unitàMisura
     * @param farmaco
     */
    public Assunzione(Date dataAssunzione, Time orario, int quantità, String unitàMisura, Farmaco farmaco) {
        this.dataAssunzione = dataAssunzione;
        this.orario = orario;
        this.quantità = quantità;
        this.unitàMisura = unitàMisura;
        this.farmaco = farmaco;
    }
}
