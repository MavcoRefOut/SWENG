import java.util.Date;

/**
 * Classe astratta per permettere alle classi specializzate di ereditare campi e metodi
 */
public abstract class Persona {
    protected String nome;

    protected String cognome;

    protected String email;

    protected Date dataNascita;

    protected String codiceFiscale;

    /**
     * Costruttore della classe Persona, parametri autodescrittivi, si presume che
     * il codice fiscale venga sempre inserito corretto (lunghezza = 16)
     * @param nome
     * @param cognome
     * @param email
     * @param dataNascita
     * @param codiceFiscale
     */
    public Persona(String nome, String cognome, String email, Date dataNascita, String codiceFiscale) {
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.dataNascita = dataNascita;
        this.codiceFiscale = codiceFiscale;
    }

    /**
     * Costruttore di default della classe
     */
    public Persona(){}

    /**
     * Metodo per effettuare il login
     * @param username username della persona
     * @param password password legata all'username
     * @return vero se la coppia username - password è presente nel sistema, altrimenti falso
     */
    public Boolean autenticazione(String username, String password) {
        return true;
    }

    /**
     * Getter di nome
     * @return nome della persona
     */
    public String getNome() {
        return nome;
    }

    /**
     * Getter di cognome
     * @return cognome della persona
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * Getter di email
     * @return email della persona
     */
    public String getEmail() {
        return email;
    }

    /**
     * Getter di dataNascita
     * @return data di nascita della persona
     */
    public Date getDataNascita() {
        return dataNascita;
    }

    /**
     * Getter di codiceFiscale
     * @return codice fiscale della persona
     */
    public String getCodiceFiscale() {
        return codiceFiscale;
    }
}
