import java.util.Date;

public class Diabetologo extends Persona{


    /**
     * Costruttore della classe, parametri autodescrittivi
     * @param nome
     * @param cognome
     * @param email
     * @param dataNascita
     * @param codiceFiscale
     */
    public Diabetologo(String nome, String cognome, String email, Date dataNascita,  String codiceFiscale) {
        super(nome, cognome, email, dataNascita, codiceFiscale);
    }

    /**
     * Override del metodo per effettuare l'accesso al sistema
     * @param username username della persona
     * @param password password legata all'username
     * @return vero se la coppia username - password è presente nel sistema, altrimenti falso
     */
    @Override
    public Boolean autenticazione(String username, String password) {
        return super.autenticazione(username, password);
    }

    //ha senso non metterli qua ma nel codice della gui del medico? usando il main non dovrebbero esserci problemi...
    public Boolean prescriviTerapia(Terapia terapia, String paziente){return true;}

    //siccome c'è una unica terapia per il diabete non ha senso indicare quale terapia modificare, la lista delle altre non va toccata
    public Boolean modificaTerapia(Terapia newTerapia, String paziente){return true;}

    //come facciamo per il riferimento al paziente? se facciamo con c.f. siamo sicuri di operare sul paziente(ricerca corrispondenza nel sistema), con l'oggetto??
    public Boolean modificaPaziente(Paziente paziente, Paziente newPaziente){return true;}

    //questo va messo nel main sennò non possiamo trovarlo, anche gli altri credo
    public String visualizzaPaziente(String paziente){
        return "";
    }
}
