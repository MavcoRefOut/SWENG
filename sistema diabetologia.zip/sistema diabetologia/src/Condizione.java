import java.util.Date;

/**
 * Classe che descrive una patologia o sintomo di un paziente
 */
public class Condizione {

    private String descrizione;
    private Date dataInizio;
    private Date dataFine;

    /**
     * Costruttore della classe
     * @param descrizione descrizione della condizione
     * @param dataInizio data in cui si è presentata la condizione
     * @param dataFine eventuale data in cui è terminata la condizione
     */
    public Condizione(String descrizione, Date dataInizio, Date dataFine) {
        this.descrizione = descrizione;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
    }

    /**
     * Getter di descrizione
     * @return descrizione
     */
    public String getDescrizione() {
        return descrizione;
    }

    /**
     * Getter di dataInizio
     * @return dataInizio condizione
     */
    public Date getDataInizio() {
        return dataInizio;
    }

    /**
     * Getter di dataFine
     * @return eventuale dataFine
     */
    public Date getDataFine() {
        return dataFine;
    }

    public void setDataFine(Date dataFine) {
        this.dataFine = dataFine;
    }
}
