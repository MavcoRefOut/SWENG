/**
 * Classe che descrive una notifica di sistema
 */
public class Notifica {

    private String testoNotifica;
    private int tipoNotifica; //0 = sollecitazione paziente, 1 = livello glucosio fuori norma, 2 = terapia non rispettata per 3gg, altro?
    private int gravità; //solo per tipo = 1, da 0 (non ha senso metterla) 1 bassa, 2 media, 3 alta

    /**
     * Costruttore della classe
     * @param testoNotifica testo della notifica ricevuta
     * @param tipoNotifica tipologia di notifica
     * @param gravità gravità del valore di glucosio
     */
    public Notifica(String testoNotifica, int tipoNotifica, int gravità) {
        this.testoNotifica = testoNotifica;
        this.tipoNotifica = tipoNotifica;
        this.gravità = gravità;
    }
}
