import java.sql.Time;
import java.util.Date;

/**
 * Classe che descrive una rilevazione del livello di glucosio di un Paziente
 */
public class Rilevazione {

    private Date dataRilevazione;
    private Time oraRilevazione;
    private int livelloGlucosio;
    private Boolean prePasto;

    /**
     * Costruttore della classe
     * @param dataRilevazione data della rilevazione
     * @param oraRilevazione orario rilevazione
     * @param livelloGlucosio livello glucosio misurato
     * @param prePasto true se la misurazione è prima di un pasto, false se è due ore dopo
     */
    public Rilevazione(Date dataRilevazione, Time oraRilevazione, int livelloGlucosio, Boolean prePasto) {
        this.dataRilevazione = dataRilevazione;
        this.oraRilevazione = oraRilevazione;
        this.livelloGlucosio = livelloGlucosio;
        this.prePasto = prePasto;
    }

    /**
     * Getter di dataRilevazione
     * @return dataRilevazione
     */
    public Date getDataRilevazione() {
        return dataRilevazione;
    }

    /**
     * Getter di oraRilevazione
     * @return oraRilevazione
     */
    public Time getOraRilevazione() {
        return oraRilevazione;
    }

    /**
     * Getter di livelloGlucosio
     * @return livelloGlucosio
     */
    public int getLivelloGlucosio() {
        return livelloGlucosio;
    }

    /**
     * Getter di prePasto
     * @return true se la misurazione è prima di un pasto, false se è due ore dopo
     */
    public Boolean getPrePasto() {
        return prePasto;
    }
}
