import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Classe che descrive un Paziente
 */
public class Paziente extends Persona {

    private List<String> fattoreRischio;
    private Diabetologo medicoCurante;
    private List<Rilevazione> rilevazioni;
    //contiene eventuali patologie o sintomi pregressi
    private List<Condizione> condizioniPregresse;
    private List<Terapia> terapieConcomitanti;
    private Terapia terapiaDiabete;

    /**
     * Costruttore della classe, i parametri sono autodescrittivi
     * @param nome
     * @param cognome
     * @param email
     * @param dataNascita
     * @param codiceFiscale
     * @param medicoCurante unico medico curante legato al diabete
     */
    public Paziente(String nome, String cognome, String email, Date dataNascita, String codiceFiscale, Diabetologo medicoCurante) {
        super(nome, cognome, email, dataNascita, codiceFiscale);
        this.medicoCurante = medicoCurante;
        fattoreRischio = new ArrayList<String>();
        rilevazioni = new ArrayList<Rilevazione>();
        condizioniPregresse = new ArrayList<Condizione>();
        terapieConcomitanti = new ArrayList<Terapia>();
        terapiaDiabete = new Terapia();
    }

    /**
     * Getter di fattoreRischio
     * @return eventuali fattori di rischio del paziente
     */
    public List<String> getFattoreRischio() {
        return fattoreRischio;
    }

    /**
     * Getter di medicoCurante
     * @return medico curante del paziente
     */
    public Diabetologo getMedicoCurante() {
        return medicoCurante;
    }

    /**
     * Getter di Rilezavioni
     * @return rilevazioni effettuate dal paziente
     */
    public List<Rilevazione> getRilevazioni() {
        return rilevazioni;
    }

    /**
     * Getter di condizioniPregresse
     * @return eventuali condizioni pregresse del paziente
     */
    public List<Condizione> getCondizioniPregresse() {
        return condizioniPregresse;
    }

    /**
     * Getter di terapieConcomitanti
     * @return terapie diverse da quella per il diabete nello stesso periodo
     */
    public List<Terapia> getTerapieConcomitanti() {
        return terapieConcomitanti;
    }




    /**
     * Metodo che permette al Paziente di aggiungere condizioni pregresse
     * @param condizione condizione da aggiungere
     * @return true se va a buon fine, false altrimenti
     */
    public Boolean aggiungiCondizione(Condizione condizione) {
        if(condizioniPregresse.add(condizione)) {
            return true;
        }
        return false;
    }

    /**
     * Metodo per effettuare una rilevazione e salvarla
     * @param rilevazione dati delal rilevazione effettuata
     * @return true se va a buon fine, false altrimenti
     */
    public Boolean effettuaRilevazione(Rilevazione rilevazione) {
        if(rilevazioni.add(rilevazione)) {
            return true;
        }
        return false;
    }

    /**
     * Metodo per aggiungere una terapia concomitante
     * @param terapia dati della terapia concomitante
     * @return true se va a buon fine, false altrimenti
     */
    public Boolean aggiungiTerapia(Terapia terapia) {
        if(terapieConcomitanti.add(terapia)) {
            return true;
        }
        return false;
    }




}
