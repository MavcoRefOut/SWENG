import java.util.List;

/**
 * Classe che descrive una Terapia prescritta a un Paziente
 */
public class Terapia {

    private int assunzioniGG;
    private String indicazioni;
    private int quantitàPrescritta;
    private Farmaco farmaco;
    private List<Assunzione> assunzioni;


    /**
     * Costruttore della classe
     * @param assunzioniGG numero di assunzioni giornaliere
     * @param indicazioni indicazioni particolari sulla terapia
     * @param quantitàPrescritta quantità prescritta per assunzione
     * @param farmaco farmaco da assumere
     * @param assunzioni lista che contiene le varie assunzioni giornaliere, con orario indicativo,
     *                   data fittizia e quantità con unità di misura
     */
    public Terapia(int assunzioniGG, String indicazioni, int quantitàPrescritta, Farmaco farmaco,  List<Assunzione> assunzioni) {
        this.assunzioniGG = assunzioniGG;
        this.indicazioni = indicazioni;
        this.quantitàPrescritta = quantitàPrescritta;
        this.farmaco = farmaco;
        this.assunzioni = assunzioni;
        if(assunzioni.size()!=assunzioniGG){
            //errore rifare la terapia
        }
    }

    /**
     * Costruttore di default della classe
     */
    public Terapia() {}
    /**
     * Getter di assunzioniGG
     * @return numero di assunzioni giornaliere del farmaco
     */
    public int getAssunzioniGG() {
        return assunzioniGG;
    }

    /**
     * Getter di indicazione
     * @return indicazioni particolari legate alla terapia
     */
    public String getIndicazioni() {
        return indicazioni;
    }

    /**
     * Getter di quantitàPrescritta
     * @return quantità da assumere
     */
    public int getQuantitàPrescritta() {
        return quantitàPrescritta;
    }

    /**
     * Getter di farmaco
     * @return farmaco da assumere per la terapia
     */
    public Farmaco getFarmaco() {
        return farmaco;
    }

    /**
     * Getter di assunzioni
     * @return lista con le varie indicazioni da fare nell'arco della giornata, la data è fittizia
     */
    public List<Assunzione> getAssunzioni() {
        return assunzioni;
    }

    public void setAssunzioniGG(int assunzioniGG) {
        this.assunzioniGG = assunzioniGG;
    }

    public void setIndicazioni(String indicazioni) {
        this.indicazioni = indicazioni;
    }

    public void setQuantitàPrescritta(int quantitàPrescritta) {
        this.quantitàPrescritta = quantitàPrescritta;
    }

    public void setFarmaco(Farmaco farmaco) {
        this.farmaco = farmaco;
    }

    public void setAssunzioni(List<Assunzione> assunzioni) {
        this.assunzioni = assunzioni;
    }
}
