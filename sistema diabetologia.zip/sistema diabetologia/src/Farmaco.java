/**
 * Classe che descrive i vari farmaci
 */
public class Farmaco {
    private String nomeFarmaco;
    private String principioAttivo;

    /**
     * Costruttore della classe
     * @param nomeFarmaco nome commerciale del farmaco
     * @param principioAttivo principio attivo del farmaco
     */
    public Farmaco(String nomeFarmaco, String principioAttivo){
        this.nomeFarmaco = nomeFarmaco;
        this.principioAttivo = principioAttivo;
    }

    /**
     * Getter di nomeFarmaco
     * @return nomeFarmaco
     */
    public String getNomeFarmaco() {
        return nomeFarmaco;
    }

    /**
     * Getter di principioAttivo
     * @return principioAttivo
     */
    public String getPrincipioAttivo() {
        return principioAttivo;
    }

    public void setNomeFarmaco(String nomeFarmaco) {
        this.nomeFarmaco = nomeFarmaco;
    }

    public void setPrincipioAttivo(String principioAttivo) {
        this.principioAttivo = principioAttivo;
    }
}
